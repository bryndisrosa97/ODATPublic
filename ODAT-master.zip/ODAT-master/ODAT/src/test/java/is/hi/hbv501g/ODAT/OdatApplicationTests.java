package is.hi.hbv501g.ODAT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdatApplicationTests {

	@Test
	void contextLoads() {
	}

}
