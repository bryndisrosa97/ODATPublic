package is.hi.hbv501g.ODAT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OdatApplication {

	public static void main(String[] args) {
		SpringApplication.run(OdatApplication.class, args);
	}

}
